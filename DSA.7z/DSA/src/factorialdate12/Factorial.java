package factorialdate12;

public class Factorial {

	int fact(int n) {
		if (n==1) {
			return n;
		}
		
		return n*fact(n-1);
	}
	public static void main(String[] args) {
		Factorial f = new Factorial();
		int num = 5;
		int factorial=f.fact(num);
		System.out.println("factorial of "+num+" = " + factorial );
	}

}
