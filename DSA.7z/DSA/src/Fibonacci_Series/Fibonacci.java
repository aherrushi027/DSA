package Fibonacci_Series;

import java.util.Scanner;

public class Fibonacci {
	long arr[]=new long[10000];
	static long i=0;
	long fib(long n ) {
		
		i++;
		
		if (n==0) {
			return 0;
		}
		else if(n==1) {
			return 1;

		}
		if(arr[(int) n]!=0) {	
			return arr[(int) n];
		}
		
		else
		{
			long fibval = fib(n-1)+fib(n-2);
			arr[(int) n]=fibval;
			return fibval;
		}
	}


	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		
		System.out.print("Enter the no : ");
		long n=sc.nextLong();
		long fibonacci = new Fibonacci().fib(n);
		System.out.println("Fibonacci "+ (n) +" = "+fibonacci);
		System.out.println("Count "+ i );
	}

}
