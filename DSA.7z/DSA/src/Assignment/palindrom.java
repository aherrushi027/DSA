package Assignment;

public class palindrom {

}
