package Assignment;

public class Magicsquare {

}
