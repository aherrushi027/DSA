package queue;

// FIFO

public class QueueUsingArray {
	int [] arr;
	int front = -1;
	int rear= -1;
	public QueueUsingArray(int capacity) {
		arr=new int[capacity];
	}
	
	
	public void enQueue(int data) {

		if(rear==arr.length-1) {
			System.out.println("Queue is full !! "+ data +" Can't Enqueue");
			return;
		}
		else {
			arr[++rear]=data;
		}
		
		
	}
	
	public void dequeue() {
		if(rear==front) {
			System.out.println("Queue Is empty");
			return;
		}
		else {
			for (int i = 1; i <= arr.length; i++) {
				if(i==arr.length) {
					
					arr[++front]=0;
					rear--;
				}
				else {
				int tepm=arr[i];
				arr[++front]=tepm;
				
				}
			}
			front=-1;
			
			
			
		}
	}
	
	public static void main(String[] args) {																			
			QueueUsingArray qa = new  QueueUsingArray(5);
			qa.enQueue(10);
			qa.enQueue(20);
			qa.enQueue(30);
			qa.enQueue(40);
			qa.enQueue(50);
			qa.enQueue(60);
			System.out.println("after enqueue ,front " +qa.front+" , rear " +qa.rear);
			qa.enQueue(30);
			qa.dequeue();
			qa.dequeue();
			qa.dequeue();
			qa.dequeue();
			qa.dequeue();
			qa.dequeue();
			qa.dequeue();
			
			System.out.println("after dequeue,front " +qa.front+" , rear " +qa.rear);

			for (int i = 0; i < qa.arr.length; i++) {
				System.out.print(qa.arr[i]+" >> ");
			}
			
	}

}
