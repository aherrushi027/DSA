package queue;

import list.ListNode;

public class QueueUsingLinkedList {

	static ListNode head;
	
	public void enqueue(int data) {
		ListNode newnode=new ListNode(data);
		if (head == null ) {
			head=newnode;
			
		}
		else {
			
			ListNode currnode=head;
			while( currnode.next != null ) {
				currnode=currnode.next;
			}
			currnode.next = newnode;
	
//			newnode.next=head;
//			head=newnode;
					
		}
		
	}
	public void dequeue() {
		if(head == null) {
			System.out.println("The Queue is Empty");
	
		}else {
			ListNode temp = head.next;
			head=null;
			head=temp;
			
		}
		
	}
	
	
	public void travelser() {
		
		if (head == null ) {
			System.out.println("Queue is Empty!! ");
	
		}
		else {
			ListNode currnode = head ;
			while(currnode != null ) {
				
				System.out.print(currnode.data);
				currnode = currnode.next;
				if(currnode != null ) {
					System.out.print(" >> ");
				}
			}
		}
		
		
	}
	
	public static void main(String[] args) {
		QueueUsingLinkedList qll =new QueueUsingLinkedList();
		qll.enqueue(10);
		qll.enqueue(20);
		qll.enqueue(30);
		qll.enqueue(40);
		qll.enqueue(50);
		
		System.out.println("\nAfter the Enqueue");
		qll.travelser();
		System.out.println("\n------------------------------------------------------");
		qll.dequeue();
		
		System.out.println("\nAfter the Dequeue\n----------------------------------------------");
		qll.travelser();
		qll.dequeue();
		
		System.out.println("\nAfter the Dequeue\n----------------------------------------------");
		qll.travelser();

		qll.dequeue();
		System.out.println("\nAfter the Dequeue\n----------------------------------------------");
		qll.travelser();
		
		qll.dequeue();
		System.out.println("\nAfter the Dequeue\n----------------------------------------------");
		qll.travelser();

		qll.dequeue();
		System.out.println("\nAfter the Dequeue\n----------------------------------------------");
		qll.travelser();

		qll.dequeue();
		System.out.println("\nAfter the Dequeue\n----------------------------------------------");
		qll.travelser();


	}

}
