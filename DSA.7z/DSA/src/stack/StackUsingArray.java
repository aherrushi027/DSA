package stack;
// LIFO

public class StackUsingArray {
	int[] arr;
	int top=-1;
	int capacity= 5;

	public StackUsingArray(int size) {
		capacity=size;
		arr =new int [capacity];
		top=-1;
	}
	
	public void push(int item) {
		if(isFull()){
			System.out.println("StackOverflow");
		return;
		}
		else {
			arr[++top]=item;
		}
		
		
	}
	
	public boolean isFull() {
		return top==capacity-1;
	}


	public boolean isEmpty() {
		return top==-1;
	}

	public void pop() {
		if(isEmpty()) {
			System.out.println("Empty stack");
			
		}
		else {
			
			System.out.println("[ "+arr[top]+" ]");
			top--;
		}
	}
	public void peek() {
		if(isEmpty()) {
			System.out.println("Empty Stack");
		}
		else {
			System.out.println("Top Item :- [ "+ arr[top] +" ]");
		}
	}
	
	public static void main(String[] args) {
		StackUsingArray sa = new StackUsingArray(5);
		sa.push(10);
		sa.push(20);
		sa.push(30);
		sa.push(40);
		sa.push(50);
		sa.push(60);
		sa.pop();
		
		sa.peek();
		
		
		
	}

}
