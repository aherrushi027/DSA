package stack;

// LIFO

import list.ListNode;
public class StackUsingList {
	
	static ListNode head;
	
	
public void push(int data) {
	 ListNode node =new ListNode(data);
	 node.next=head;
	 head=node;
	 return;
	 
}
public void pop() {
	if(head == null) {
		System.out.println("Empty Stack");
		return;
	}else {
		
		ListNode temp = head.next;
		System.out.println("Pop = [ "+ head.data +" ]");
		head=null;
		
		head=temp;
		
	}
}
public void peek() {
	if(head == null) {
		System.out.println("Empty Stack");
		return;
	}
	System.out.println("\n");
	System.out.println("Peek = [ "+ head.data +" ]");
	System.out.println("\n");

}
public void traversal() {
	if(head == null) {
		System.out.println("Empty Stack");
		return;
	}
	else {
		ListNode currnode=head;
		System.out.println("\n");
		while(currnode!=null) {
			System.out.print(currnode.data+" >> ");
			currnode=currnode.next;
		}
		System.out.println("\n");
	}
	
}

	
	public static void main(String[] args) {
		StackUsingList sl =new StackUsingList();
		
		sl.push(10);
		sl.push(20);
		sl.push(30);
		sl.push(40);
		sl.push(50);
		
		sl.traversal();
		
		sl.pop();
		
		sl.peek();
		
		sl.traversal();

		sl.pop();
		
		sl.traversal();
		
		sl.peek();
	}

}
