package binarySearchday5;
import java.util.Scanner;

public class BinarynoArrya {

	static int arr[] = new int []{12,15,45,18,654,78,56,47,58,5,95,25,745,725,25,79,54,59,23,28};
	static int low = 0 ;
	static int index=-1;
	static int high =arr.length-1 ;

	
	void binarySerch(int num) {
		
		int avg =(low + high)/2;
		if(arr[avg]==num) {
			System.out.println("No is "+arr[avg]+" Index of no. "+avg );
			return ;
		}
		
		if(arr[avg]!=num) {
			if(arr[avg]<num) {
				high=avg-1;
			}
			else
			{
				low=avg+1;
			}
			
			System.out.println("No is "+arr[avg]+" Index of no. "+avg );
			return ;
		}
	}
	public static void main(String[] args) 
	{
	}
	
}

