package list;

 class DoublyLinkedList{
	static DoublyNode head;

	public void insertBeforeHead(int data) {
		DoublyNode newnode = new DoublyNode(data);
		if(head==null) {
			System.out.println("Empty list");
			head=newnode;
		}
		else {
			newnode.next=head;
			newnode=head;
		}
	}
	public void insertAtLast(int data) {
		DoublyNode newnode = new DoublyNode(data);
		if(head==null) {
			System.out.println("Empty list");
			head=newnode;
		}
		else {
			DoublyNode currnode = head ;
			while(currnode.next != null) {
				currnode=currnode.next;
			}
			currnode.next = newnode;
			newnode.pre = currnode;
			
		}
	}
	public void insertBeforeNode(int data,int val) {
		DoublyNode newnode = new DoublyNode(data);
		if(head==null) {
			System.out.println("Empty list");
			head=newnode;
		}
		else {
			DoublyNode currnode = head ;
			while(currnode.data != val) {
					currnode = currnode.next;
					
					
			}
		}
	}
	public void insertAfternNode(int data) {
		DoublyNode newnode = new DoublyNode(data);
		if(head==null) {
			System.out.println("Empty list");
			head=newnode;
		}
	}
	
	
	
	
	
	
	
	
	
	
}

 public class DoublyNode{
	int data;
	DoublyNode next;
	DoublyNode pre;
	public DoublyNode(int data) {
		this.data=data;
		next = null ;
		pre = null ;
	}
	
	
	

	public static void main(String[] args) {

	}

}


