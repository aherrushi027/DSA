package list;

 class SinglyLinkedList {
	
	static ListNode head;	
	
	
	public void insertBeforeHead(int data) {
		ListNode newnode = new ListNode(data);
		
		if (head == null ) {
			System.out.println("Empty list");
			head = newnode;
			return;
		}
		
		newnode.next=head;
		head=newnode;
		
	}
	
	public void insertAtLast(int data) {
		
		ListNode newnode = new ListNode(data);
		ListNode temp = head;
		while(temp.next !=null) {
			
			
			temp=temp.next;
			
		}
		temp.next = newnode;
//	System.out.println(temp.next);
	}
	public void insertAfterNode(int ele,int data) {
		
		ListNode newnode = new ListNode(data);
		ListNode temp = head;
		while(temp.data != ele) {
	
			temp=temp.next;
		}
		
		ListNode temp1=temp.next;
		temp.next = newnode;
		newnode.next =temp1;
//	System.out.println(temp.next);
	}
	
public void insertBeforeNode(int ele,int data) {
		
	
	ListNode newnode = new ListNode(data);
	ListNode temp = head;
	while(temp.data != ele) {
			if(temp.next.data == ele) {   // check the temp node next has required data get previous node
				ListNode temp1=temp.next; // Assign previous node in temp1
				temp.next=newnode;		  
				newnode.next = temp1;
				return;
			}
			temp=temp.next;               // next node push in temp    

			
		}
		
	
//	System.out.println(temp.next);
	}
	

public void deleteHead() {
	if(head == null ) {
		System.out.println("The List Is Empty");
	}
	
	ListNode temp = head.next;

	head=null;
		
	head=temp;
	
	
	
}


public void deleteAtLast() {
	if(head == null) {
		System.out.println("The List is Empty");
	}
	if(head.next == null) {
		head = null;
		return;
	}
	ListNode prenode = head;
	ListNode currnode = head;
	while (currnode.next != null) {
	
		prenode=currnode;
		
		currnode=currnode.next;

	}
	prenode.next=null;
	currnode=null;

}
public void deleteInBetween(int data) {	
	if (head==null) {
		System.out.println("The list is Empty");
	}
	
	if(head.next == null ) {
		if(head.data == data) {
		
		head=null;
		System.out.println("The list is Empty");
		return;
		}
		
		else {
			System.out.println("Data not Present At this time!!");
			return;
		}
	}
	ListNode prenode =head;
	ListNode currnode = head;
	while(currnode.data!=data) {
		prenode=currnode;
		currnode=currnode.next;
	}
	prenode.next=currnode.next;
	currnode=null;
			
}
	
	public void display() {
		
		if(head==null) {
			System.out.println("The linked list is empty");
			return;
		}
		ListNode currnode = head;
		while(currnode != null) {
			System.out.print(currnode.data);
			
			if(currnode.next!=null)
				System.out.print(" >> ");

//			System.out.print(currnode.data+" "+currnode.next+" >> ");
			currnode = currnode.next;
		}
//		System.out.println("null");
	}
	
	

}


public class ListNode {
	public int data;
	public ListNode next;
	
	public ListNode(int data) {
		this.data=data;
		this.next=null;
	}
	
	public static void main(String[] args) {
		SinglyLinkedList sll=new SinglyLinkedList();
		sll.head = new ListNode(50);
		
		sll.deleteInBetween(10);
		sll.insertBeforeHead(40);
		sll.insertBeforeHead(30);
		sll.insertBeforeHead(20);
		sll.insertBeforeHead(10);
		sll.insertBeforeHead(00);
		
		
		
		sll.insertAtLast(60);
		sll.insertAtLast(70);
		sll.insertAtLast(80);
		
		sll.insertAfterNode(60, 65);
		sll.insertAfterNode(70, 75);
		sll.insertAfterNode(80, 85);
		
		sll.insertBeforeNode(60, 55);
		
		
		sll.deleteHead();
		sll.deleteHead();
		
		sll.deleteAtLast();
		sll.deleteAtLast();
		
		sll.display();
		
		

	}
	
	
}
