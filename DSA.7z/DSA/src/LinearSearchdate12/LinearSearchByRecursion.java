package LinearSearchdate12;

import java.util.Scanner;

public class LinearSearchByRecursion {
	static int arr[] = new int []{12,15,45,18,654,78,56,47,58,5,95,25,745,725,25,79,54,59,23,28};
	static int index=-1;
	public static int search(int num) {
		
		index++;
		if(arr[index]==num) {		
		return index;
		}
		if(arr[index]!=num && index == arr.length-1) {
			System.out.println("No. Not in array");
			return index; 
		}
		return search(num);
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. to Search");
		int num=sc.nextInt();
		
		int i =search(num);
		System.out.println("Index " + i );
		sc.close();
	}
	public static void main1(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. to Search");
		int num=sc.nextInt();
		for (int i = 0; i < arr.length; i++) {
			if(arr[i]==num)
				System.out.println("index of No. " + i);
			else if(i==arr.length-1)
			System.out.println(i);
		}
		sc.close();
	}
}
